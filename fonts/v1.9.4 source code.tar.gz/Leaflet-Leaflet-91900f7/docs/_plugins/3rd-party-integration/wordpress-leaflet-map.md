---
name: WordPress Leaflet Map
category: 3rd-party-integration
repo: https://wordpress.org/plugins/leaflet-map/
author: Benjamin J DeLong
author-url: https://bozdoz.com/projects/leaflet-map
demo: 
compatible-v0:
compatible-v1: true
---

Interactive and flexible shortcode to create multiple maps in posts and pages,			and to add multiple markers on those maps.
