---
name: RaphaelLayer
category: dataviz
repo: https://github.com/dynmeth/RaphaelLayer
author: Dynamic Methods
author-url: https://github.com/dynmeth
demo: 
compatible-v0:
compatible-v1: true
---

Allows you to use <a href="http://raphaeljs.com/">Raphael</a> as a layer on a Leaflet map for advanced animations and visualizations.
