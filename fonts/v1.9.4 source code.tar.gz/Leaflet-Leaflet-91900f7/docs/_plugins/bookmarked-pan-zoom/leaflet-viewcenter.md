---
name: Leaflet.viewcenter
category: bookmarked-pan-zoom
repo: https://github.com/pwldp/leaflet.viewcenter
author: Dariusz Pawlak
author-url: https://github.com/pwldp/
demo: https://pwldp.github.io/leaflet.viewcenter/
compatible-v0:
compatible-v1: true
---

A simple control that adds a button to change view and zoom to predefined values in options.
