---
name: Leaflet.Icon.Glyph
category: markers-renderers
repo: https://github.com/Leaflet/Leaflet.Icon.Glyph
author: Iván Sánchez Ortega
author-url: https://github.com/IvanSanchez
demo: https://leaflet.github.io/Leaflet.Icon.Glyph/demo.html
compatible-v0:
compatible-v1: true
---

Use icon font glyphs in your markers (from Font Awesome, Material Design Icons, Glyphicons,			Metro UI icons, Elusive, and other icon fonts).
