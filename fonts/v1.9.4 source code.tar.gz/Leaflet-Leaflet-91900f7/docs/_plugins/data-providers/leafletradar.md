---
name: leaflet-radar
category: data-providers
repo: https://github.com/rwev/leaflet-radar
author: rwev
author-url: https://github.com/rwev/
demo: https://rwev.github.io/leaflet-radar/
compatible-v0:
compatible-v1: true
---

Animated satellite weather radar overlays for Leaflet.
