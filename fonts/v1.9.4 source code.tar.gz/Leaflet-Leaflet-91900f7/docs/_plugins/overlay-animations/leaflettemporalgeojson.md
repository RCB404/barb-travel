---
name: leaflet-temporal-geojson
category: overlay-animations
repo: https://github.com/onaci/leaflet-temporal-geojson
author: danwild
author-url: https://github.com/danwild
demo: https://onaci.github.io/leaflet-temporal-geojson/
compatible-v0:
compatible-v1: true
---

Flexible animation of GeoJSON features.
