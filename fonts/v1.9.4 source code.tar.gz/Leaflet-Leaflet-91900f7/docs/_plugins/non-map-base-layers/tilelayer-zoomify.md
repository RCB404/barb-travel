---
name: TileLayer.Zoomify
category: non-map-base-layers
repo: https://github.com/cmulders/Leaflet.Zoomify
author: Bjørn Sandvik
author-url: https://github.com/turban
demo: https://cmulders.github.io/Leaflet.Zoomify/examples/hubble-image.html
compatible-v0:
compatible-v1: true
---

A TileLayer for Zoomify images.
