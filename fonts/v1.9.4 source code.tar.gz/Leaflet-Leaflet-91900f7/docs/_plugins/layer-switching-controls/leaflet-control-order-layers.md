---
name: Leaflet Control Order Layers
category: layer-switching-controls
repo: http://elesdoar.github.io/leaflet-control-orderlayers/
author: Michael Salgado
author-url: https://github.com/elesdoar/
demo: 
compatible-v0:
compatible-v1: true
---

Adds the ability to change overlay order in the layers control.
