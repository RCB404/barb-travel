---
name: Leaflet.TileLayer.IIP
category: non-map-base-layers
repo: https://github.com/astromatic/Leaflet.TileLayer.IIP
author: Emmanuel Bertin
author-url: https://github.com/ebertin
demo: http://image.iap.fr/iip/
compatible-v0:
compatible-v1: true
---

Add support for <a href="https://iipimage.sourceforge.io/">IIPImage</a> layers in Leaflet.
