---
name: Leaflet.draw
category: edit-geometries
repo: https://github.com/Leaflet/Leaflet.draw
author: Jacob Toye
author-url: https://github.com/jacobtoye
demo: 
compatible-v0:
compatible-v1: true
---

Enables drawing features like polylines, polygons, rectangles, circles and markers through a very nice user-friendly interface with icons and hints.
