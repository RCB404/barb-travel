---
name: Leaflet.MovingMarker
category: overlay-animations
repo: https://github.com/ewoken/Leaflet.MovingMarker
author: Ewoken
author-url: https://github.com/ewoken
demo: http://ewoken.github.io/Leaflet.MovingMarker/
compatible-v0:
compatible-v1: true
---

Allow to move markers along a polyline with custom durations.
