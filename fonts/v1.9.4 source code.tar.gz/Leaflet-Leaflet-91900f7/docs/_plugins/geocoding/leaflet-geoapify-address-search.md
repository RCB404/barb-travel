---
name: Leaflet Geoapify Address Search
category: geocoding
repo: https://github.com/geoapify/leaflet-address-search-plugin
author: Geoapify
author-url: https://github.com/geoapify
demo: https://geoapify.github.io/leaflet-address-search-plugin/
compatible-v0:
compatible-v1: true
---
Adds an Address Autocomplete field to the map, powered by <a href="https://www.geoapify.com/">Geoapify</a>.
