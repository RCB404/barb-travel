---
name: Leaflet.ScaleFactor
category: measurement
repo: https://github.com/MarcChasse/leaflet.ScaleFactor
author: Marc Chasse
author-url: https://github.com/MarcChasse
demo: https://marcchasse.github.io/leaflet.ScaleFactor/
compatible-v0:
compatible-v1: true
---

Display a Scale Factor (e.g. 1:50,000) for Leaflet maps.
