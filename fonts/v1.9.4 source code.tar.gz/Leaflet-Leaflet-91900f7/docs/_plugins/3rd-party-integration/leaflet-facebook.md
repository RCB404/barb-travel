---
name: Leaflet.Facebook
category: 3rd-party-integration
repo: https://github.com/mwasil/Leaflet.Facebook/
author: Marcin Wasilewski
author-url: https://marcinwasilewski.eu/
demo: 
compatible-v0:
compatible-v1: true
---

Simple plugin for adding Facebook like button as a control.
