---
name: Leaflet.FileGDB
category: overlay-data-formats
repo: https://github.com/calvinmetcalf/leaflet.filegdb
author: Calvin Metcalf
author-url: https://github.com/calvinmetcalf
demo: 
compatible-v0:
compatible-v1: true
---

Put an ESRI File GeoDatabase onto your map as a layer.
