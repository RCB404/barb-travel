---
name: leaflet-usermarker
category: markers-renderers
repo: https://github.com/heyman/leaflet-usermarker
author: Jonatan Heyman
author-url: https://heyman.info/
demo: 
compatible-v0:
compatible-v1: true
---

Plugin for plotting a marker representing a user - or multiple users - on a map,			with support for drawing an accuracy circle. Can be seen in action on			<a href="https://longitude.me/">Longitude.me</a>.
