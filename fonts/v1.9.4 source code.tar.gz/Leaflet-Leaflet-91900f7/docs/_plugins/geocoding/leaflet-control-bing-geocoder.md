---
name: Leaflet Control Bing Geocoder
category: geocoding
repo: https://github.com/sa3m/leaflet-control-bing-geocoder
author: Samuel Piquet
author-url: https://github.com/sa3m
demo: http://sa3m.github.io/leaflet-control-bing-geocoder/
compatible-v0:
compatible-v1: true
---

A simple geocoder control that uses Bing to locate places. You may be also interested in its fork <a href="https://github.com/perliedman/leaflet-control-geocoder">Leaflet Control Geocoder</a>.
