---
name: Leaflet.Snap
category: edit-geometries
repo: https://github.com/makinacorpus/Leaflet.Snap
author: Mathieu Leplatre
author-url: https://github.com/leplatrem
demo: https://makinacorpus.github.io/Leaflet.Snap/
compatible-v0:
compatible-v1: true
---

Enables snapping of draggable markers to polylines and other layers.
