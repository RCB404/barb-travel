---
name: Leaflet.SegmentEdit
category: edit-geometries
repo: https://github.com/Lemaf/leaflet-polyline-segment-edit
author: Lemaf
author-url: https://github.com/Lemaf
demo: https://lemaf.github.io/leaflet-polyline-segment-edit/
compatible-v0:
compatible-v1: true
---

An extension to Leaflet.draw to allow editing large polylines one chunk at the time.
