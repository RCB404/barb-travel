---
name: Leaflet.SmoothMarkerBouncing
category: overlay-animations
repo: https://github.com/hosuaby/Leaflet.SmoothMarkerBouncing
author: Alexei KLENIN
author-url: https://github.com/hosuaby
demo: https://hosuaby.github.io/Leaflet.SmoothMarkerBouncing/
compatible-v0:
compatible-v1: true
---

Smooth animation of marker bouncing for Leaflet.
