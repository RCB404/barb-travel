---
name: L.MapkitMutant
category: basemap-providers
repo: https://gitlab.com/IvanSanchez/Leaflet.MapkitMutant
author: Iván Sánchez
author-url: https://github.com/IvanSanchez
demo: 
compatible-v0:
compatible-v1: true
---

Displays Apple's MapkitJS basemaps.
