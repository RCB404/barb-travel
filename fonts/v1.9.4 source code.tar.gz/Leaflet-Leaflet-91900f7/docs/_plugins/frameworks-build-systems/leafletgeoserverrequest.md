---
name: leaflet-geoserver-request
category: frameworks-build-systems
repo: https://github.com/iamtekson/leaflet-geoserver-request
author: Iamtekson
author-url: https://github.com/iamtekson
demo: https://iamtekson.github.io/leaflet-geoserver-request/examples/maps.html
compatible-v0:
compatible-v1: true
---

Basic geoserver requests in leaflet. Currently supports wms, wfs, legend, wmsImage request on the leaflet.
