---
name: Leaflet.Shapefile
category: overlay-data-formats
repo: https://github.com/calvinmetcalf/leaflet.shapefile
author: Calvin Metcalf
author-url: https://github.com/calvinmetcalf
demo: https://leaflet.calvinmetcalf.com/
compatible-v0:
compatible-v1: true
---

Put a shapefile onto your map as a layer.
