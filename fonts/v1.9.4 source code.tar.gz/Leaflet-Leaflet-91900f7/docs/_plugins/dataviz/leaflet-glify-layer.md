---
name: Leaflet.glify.layer
category: dataviz
repo: https://github.com/onaci/Leaflet.glify.layer
author: onaci
author-url: https://github.com/onaci
demo: https://onaci.github.io/Leaflet.glify.layer/
compatible-v0:
compatible-v1: true
---

Add-on for the Leaflet.glify plugin to provide more leaflet-idiomatic bindings. Provides fast webgl rendering for GeoJSON FeatureCollections (currently limited to polygons, lines and points).
