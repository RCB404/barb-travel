---
name: Leaflet for R
category: dataviz
repo: https://github.com/rstudio/leaflet
author: RStudio team
author-url: https://github.com/rstudio/
demo: https://rstudio.github.io/leaflet/
compatible-v0:
compatible-v1: true
---

Allows using Leaflet from within <a href="https://en.wikipedia.org/wiki/R_%28programming_language%29">R</a> programs, a programming language popular for statistical analysis and data mining.
