---
name: Tiny Leaflet Directive
category: frameworks-build-systems
repo: https://github.com/CleverMaps/tiny-leaflet-directive
author: Martin Tesař
author-url: https://github.com/mattesCZ
demo: 
compatible-v0:
compatible-v1: true
---

Tiny LeafletJS map directive for your AngularJS apps.
