---
name: azgs-leaflet
category: basemap-formats
repo: https://github.com/azgs/azgs-leaflet
author: AZGS
author-url: https://github.com/azgs
demo: 
compatible-v0:
compatible-v1: true
---

A set of small plugins for Leaflet, including WFS-GeoJSON layer with filtering, a hover control for GeoJSON, and an Esri tile layer.
