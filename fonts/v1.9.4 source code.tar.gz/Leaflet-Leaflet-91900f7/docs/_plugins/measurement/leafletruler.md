---
name: leaflet-ruler
category: measurement
repo: https://github.com/gokertanrisever/leaflet-ruler
author: Goker Tanrisever
author-url: https://github.com/gokertanrisever
demo: https://gokertanrisever.github.io/leaflet-ruler/
compatible-v0:
compatible-v1: true
---

A simple leaflet plugin to measure true bearing and distance between clicked points.
