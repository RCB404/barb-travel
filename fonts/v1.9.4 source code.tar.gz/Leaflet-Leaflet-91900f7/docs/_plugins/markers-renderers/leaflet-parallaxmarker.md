---
name: Leaflet.ParallaxMarker
category: markers-renderers
repo: https://github.com/dagjomar/Leaflet.ParallaxMarker
author: Dag Jomar Mersland
author-url: https://github.com/dagjomar/
demo: https://dagjomar.github.io/Leaflet.ParallaxMarker/
compatible-v0:
compatible-v1: true
---

Add markers that moves with a parallax-effect relative to the map when panning.
