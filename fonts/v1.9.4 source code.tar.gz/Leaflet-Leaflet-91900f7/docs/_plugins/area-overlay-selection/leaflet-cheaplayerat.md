---
name: Leaflet.CheapLayerAt
category: area-overlay-selection
repo: https://github.com/IvanSanchez/Leaflet.CheapLayerAt
author: Iván Sánchez Ortega
author-url: https://github.com/IvanSanchez
demo: http://ivansanchez.github.io/Leaflet.CheapLayerAt/demo.html
compatible-v0:
compatible-v1: true
---

Allows querying which layer is under a screen coordinate.
