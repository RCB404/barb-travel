---
name: Leaflet GeoIP Locator
category: geocoding
repo: https://github.com/jakubdostal/leaflet-geoip
author: Jakub Dostal
author-url: https://github.com/jakubdostal
demo: 
compatible-v0:
compatible-v1: true
---

A simple plugin that allows finding the approximate location of IP addresses and map centering on said location.
