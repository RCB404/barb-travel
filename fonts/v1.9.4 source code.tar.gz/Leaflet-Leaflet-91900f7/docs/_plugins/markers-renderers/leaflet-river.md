---
name: Leaflet.River
category: markers-renderers
repo: https://github.com/ggolikov/Leaflet.River
author: Grigory Golikov
author-url: https://github.com/ggolikov
demo: https://ggolikov.github.io/Leaflet.River/
compatible-v0:
compatible-v1: true
---

Draw lines with different width (like rivers) on a map. Useful when you want to show how rivers 'flow' on the map.
