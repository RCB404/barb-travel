---
name: Leaflet.StyleEditor
category: edit-geometries
repo: https://github.com/dwilhelm89/Leaflet.StyleEditor
author: Dennis Wilhelm
author-url: https://github.com/dwilhelm89
demo: https://dwilhelm89.github.io/Leaflet.StyleEditor/
compatible-v0:
compatible-v1: true
---

Enables editing the styles of features (lines, polygons, etc) and markers with a GUI.
