---
name: WP MapIt
category: 3rd-party-integration
repo: https://wp-mapit.chandnipatel.in/
author: Chandni Patel
author-url: https://chandnipatel.in/
demo: 
compatible-v0:
compatible-v1: true
---

Easy to use, WordPress Map plugin based on Open Street Map and Leaflet with custom markers images, descriptions and links.
