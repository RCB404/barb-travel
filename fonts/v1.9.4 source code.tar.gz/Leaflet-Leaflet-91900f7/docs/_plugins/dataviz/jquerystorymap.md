---
name: jquery-storymap
category: dataviz
repo: https://github.com/atlefren/storymap
author: Atle Frenvik Sveen
author-url: https://github.com/atlefren
demo: http://atlefren.github.io/storymap/
compatible-v0:
compatible-v1: true
---

A jQuery plugin to display several map locations as the user scrolls through paragraphs.
