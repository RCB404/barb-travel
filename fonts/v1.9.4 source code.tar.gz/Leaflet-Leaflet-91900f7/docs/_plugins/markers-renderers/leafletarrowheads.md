---
name: Leaflet-arrowheads
category: markers-renderers
repo: https://github.com/slutske22/leaflet-arrowheads
author: Slutske22
author-url: https://github.com/slutske22
demo: https://codesandbox.io/s/leaflet-arrowheads-example-zfxxc
compatible-v0:
compatible-v1: true
---

Allows user to quickly draw arrowheads on polylines for vector visualization.
