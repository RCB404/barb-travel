---
name: Leaflet.projwmts
category: basemap-formats
repo: https://github.com/GeoportalPL/leaflet.projwmts
author: Geoportal Poland
author-url: https://github.com/GeoportalPL
demo: https://geoportalpl.github.io/leaflet.projwmts/examples/wmts_services.html
compatible-v0:
compatible-v1: true
---

Adding WMTS services (GUGiK Poland).
