---
name: Leaflet.Spain.WMS
category: basemap-providers
repo: https://github.com/sigdeletras/Leaflet.Spain.WMS
author: Patricio Soriano
author-url: https://github.com/sigdeletras
demo: 
compatible-v0:
compatible-v1: true
---

Provides easy setup for several Web Map Services (WMS) layers for Spain (PNOA, IGN base, Catastro, etc), from Spanish mapping agencies.
