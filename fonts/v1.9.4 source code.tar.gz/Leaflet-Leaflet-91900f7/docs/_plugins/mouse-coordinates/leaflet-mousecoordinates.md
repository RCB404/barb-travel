---
name: Leaflet.mouseCoordinates
category: mouse-coordinates
repo: https://github.com/PowerPan/leaflet.mouseCoordinate
author: Johannes Rudolph
author-url: https://github.com/PowerPan
demo: 
compatible-v0:
compatible-v1: true
---

Displays the mouse coordinate in a box. Multiple formats are possible: GPS, UTM, UTMREF / MGRS, QTH
