---
name: Leaflet Copy Coordinates Control
category: mouse-coordinates
repo: https://github.com/tinjaw/Leaflet-Copy-Coordinates-Control
author: Chaim Krause
author-url: https://github.com/tinjaw
demo: https://tinjaw.github.io/Leaflet-Copy-Coordinates-Control/
compatible-v0:
compatible-v1: true
---

Works with Leaflet to capture mouseclicks on a map and display the associated coordinates with an easy way to copy them. (Derived from original work by zimmicz. Forked mainly to provide npm functionality.)
