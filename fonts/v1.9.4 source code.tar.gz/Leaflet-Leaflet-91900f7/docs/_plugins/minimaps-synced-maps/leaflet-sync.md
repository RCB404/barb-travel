---
name: Leaflet.Sync
category: minimaps-synced-maps
repo: https://github.com/jieter/Leaflet.Sync
author: Bjørn Sandvik
author-url: https://github.com/turban
demo: https://jieter.github.io/Leaflet.Sync/examples/dual.html
compatible-v0:
compatible-v1: true
---

Synchronized view of two maps.
