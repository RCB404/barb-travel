---
name: leaflet-reticle
category: measurement
repo: https://github.com/rwev/leaflet-reticle
author: rwev
author-url: https://github.com/rwev
demo: https://rwev.github.io/leaflet-reticle/
compatible-v0:
compatible-v1: true
---

Leaflet control adding a centering reticle consisting of independently calculated latitude and longitude scales.
