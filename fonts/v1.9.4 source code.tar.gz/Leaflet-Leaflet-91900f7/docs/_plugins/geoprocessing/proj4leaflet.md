---
name: Proj4Leaflet
category: geoprocessing
repo: https://github.com/kartena/Proj4Leaflet
author: Kartena
author-url: http://www.kartena.se/index.html
demo: https://kartena.github.io/Proj4Leaflet/#examples
compatible-v0:
compatible-v1: true
---

<a href="https://trac.osgeo.org/proj4js/">Proj4js</a> integration plugin, allowing you to use all kinds of weird projections in Leaflet.
