---
name: Leaflet.defaultextent
category: bookmarked-pan-zoom
repo: https://github.com/nguyenning/Leaflet.defaultextent
author: Alex Nguyen
author-url: https://github.com/nguyenning
demo: 
compatible-v0:
compatible-v1: true
---

A control that returns to the original start extent of the map.  Similar to the <a href="/javascript/3/jssamples/widget_home.html">HomeButton</a> widget.
