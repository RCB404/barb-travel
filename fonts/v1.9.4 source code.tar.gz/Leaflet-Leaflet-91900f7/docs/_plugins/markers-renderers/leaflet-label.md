---
name: Leaflet.label
category: markers-renderers
repo: https://github.com/Leaflet/Leaflet.label
author: Jacob Toye
author-url: https://github.com/jacobtoye
demo: 
compatible-v0:
compatible-v1: true
---

Adds text labels to map markers and vector layers.
