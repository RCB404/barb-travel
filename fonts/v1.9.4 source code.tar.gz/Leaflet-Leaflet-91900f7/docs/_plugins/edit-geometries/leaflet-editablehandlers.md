---
name: Leaflet.EditableHandlers
category: edit-geometries
repo: https://github.com/kartena/Leaflet.EditableHandlers
author: Kartena
author-url: http://www.kartena.se/index.html
demo: 
compatible-v0:
compatible-v1: true
---

A set of plugins that includes circle editing, measuring tool, and label for polygon sides.
