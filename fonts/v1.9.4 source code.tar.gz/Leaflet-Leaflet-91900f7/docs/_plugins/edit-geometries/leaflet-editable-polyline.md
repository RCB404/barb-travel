---
name: Leaflet.Editable.Polyline
category: edit-geometries
repo: https://github.com/tkrajina/leaflet-editable-polyline
author: Tomo Krajina
author-url: https://github.com/tkrajina
demo: https://tkrajina.github.io/leaflet-editable-polyline/example1.html
compatible-v0:
compatible-v1: true
---

Editable polylines: move existing points, add new points and split polylines.
