---
name: Leaflet.MeasureAreaControl
category: measurement
repo: https://github.com/zvaraondrej/Leaflet.MeasureAreaControl
author: Ondrej Zvara
author-url: https://github.com/zvaraondrej
demo: http://zvaraondrej.github.io/Leaflet.MeasureAreaControl/example/
compatible-v0:
compatible-v1: true
---

Control for measuring element's area.
