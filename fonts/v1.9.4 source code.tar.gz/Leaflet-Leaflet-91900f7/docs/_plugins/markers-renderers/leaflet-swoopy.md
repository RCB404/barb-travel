---
name: Leaflet Swoopy
category: markers-renderers
repo: https://github.com/wbkd/leaflet-swoopy
author: webkid
author-url: https://webkid.io/
demo: https://wbkd.github.io/leaflet-swoopy/
compatible-v0:
compatible-v1: true
---

A plugin for creating customizable swoopy arrow annotations.
