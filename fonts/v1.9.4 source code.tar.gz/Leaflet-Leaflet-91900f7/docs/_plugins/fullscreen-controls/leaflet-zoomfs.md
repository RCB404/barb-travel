---
name: leaflet.zoomfs
category: fullscreen-controls
repo: https://github.com/elidupuis/leaflet.zoomfs
author: Eli Dupuis
author-url: https://github.com/elidupuis
demo: 
compatible-v0: true
compatible-v1: false
---

A fullscreen button control.
