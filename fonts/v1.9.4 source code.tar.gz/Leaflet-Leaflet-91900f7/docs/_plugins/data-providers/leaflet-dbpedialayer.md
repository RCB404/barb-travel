---
name: Leaflet.dbpediaLayer
category: data-providers
repo: https://github.com/kr1/Leaflet.dbpediaLayer/
author: Kr1
author-url: https://github.com/kr1/
demo: 
compatible-v0:
compatible-v1: true
---

A layer with Points of interest from Wikipedia - loaded via ajax from DBpedia's SPARQL endpoint.
