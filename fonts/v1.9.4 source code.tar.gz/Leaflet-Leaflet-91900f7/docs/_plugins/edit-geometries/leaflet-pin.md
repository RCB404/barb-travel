---
name: Leaflet.Pin
category: edit-geometries
repo: https://github.com/kklimczak/Leaflet.Pin
author: Konrad Klimczak
author-url: https://github.com/kklimczak
demo: https://kklimczak.github.io/Leaflet.Pin/
compatible-v0:
compatible-v1: true
---

Enable attaching of markers to other layers during draw or edit features with Leaflet.Draw.
