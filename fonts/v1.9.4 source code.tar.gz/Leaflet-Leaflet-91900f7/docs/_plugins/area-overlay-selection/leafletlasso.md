---
name: leaflet-lasso
category: area-overlay-selection
repo: https://github.com/zakjan/leaflet-lasso
author: Jan Zak
author-url: https://github.com/zakjan
demo: https://zakjan.github.io/leaflet-lasso/
compatible-v0:
compatible-v1: true
---

Lasso selection plugin.
