---
name: Leaflet.FreieTonne
category: data-providers
repo: https://github.com/facilmap/Leaflet.FreieTonne
author: Candid Dauth
author-url: https://github.com/cdauth
demo: https://unpkg.com/leaflet-freie-tonne/example.html
compatible-v0:
compatible-v1: true
---

An overlay with nautical features from <a href="https://www.freietonne.de/">FreieTonne</a>.
