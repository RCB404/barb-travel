---
name: Leaflet-active-area
category: events
repo: https://github.com/Mappy/Leaflet-active-area
author: Mappy
author-url: https://github.com/Mappy
demo: https://techblog.mappy.com/Leaflet-active-area/examples/index.html
compatible-v0:
compatible-v1: true
---

This plugin allows you to use a smaller portion of the map as an active area. All positioning methods (setView, fitBounds, setZoom) will be applied on this portion instead of the all map.
