---
name: leaflet-marker-direction
category: markers-renderers
repo: https://github.com/JackZouShao/leaflet-marker-direction
author: Jack Zou
author-url: https://github.com/JackZouShao
demo: https://jackzoushao.github.io/leaflet-marker-direction/examples/marker-direction.html
compatible-v0:
compatible-v1: true
---

display the path and the direction of the marker.
