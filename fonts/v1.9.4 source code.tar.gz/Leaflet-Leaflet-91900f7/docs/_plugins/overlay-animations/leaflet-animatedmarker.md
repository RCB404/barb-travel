---
name: Leaflet.AnimatedMarker
category: overlay-animations
repo: https://github.com/openplans/Leaflet.AnimatedMarker
author: Aaron Ogle
author-url: https://github.com/atogle
demo: 
compatible-v0:
compatible-v1: true
---

Animate a marker along a polyline.
