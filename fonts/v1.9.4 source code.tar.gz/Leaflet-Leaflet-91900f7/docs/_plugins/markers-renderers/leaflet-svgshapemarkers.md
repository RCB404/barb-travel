---
name: Leaflet.SvgShapeMarkers
category: markers-renderers
repo: https://github.com/rowanwins/Leaflet.SvgShapeMarkers
author: Rowan Winsemius
author-url: https://github.com/rowanwins/
demo: https://rowanwins.github.io/Leaflet.SvgShapeMarkers/example/
compatible-v0:
compatible-v1: true
---

Adds support for additional SVG marker types such as triangles, diamonds and squares.
