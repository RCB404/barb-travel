---
name: V-Leaflet
category: frameworks-build-systems
repo: https://github.com/mstahv/v-leaflet
author: Matti Tahvonen
author-url: https://github.com/mstahv
demo: 
compatible-v0:
compatible-v1: true
---

Use Leaflet as a component for the <a href="https://vaadin.com/">Vaadin</a> Java/HTML framework.
