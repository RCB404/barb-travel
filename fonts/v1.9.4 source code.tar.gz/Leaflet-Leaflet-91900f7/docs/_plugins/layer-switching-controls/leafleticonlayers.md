---
name: Leaflet-IconLayers
category: layer-switching-controls
repo: https://github.com/ScanEx/Leaflet-IconLayers
author: Alexander Zverev
author-url: https://github.com/zverev
demo: http://scanex.github.io/Leaflet-IconLayers/examples/
compatible-v0:
compatible-v1: true
---

Leaflet control that displays base layers as small icons.
