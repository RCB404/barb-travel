---
name: Esri Leaflet
category: basemap-providers
repo: https://esri.github.io/esri-leaflet/
author: Patrick Arlt
author-url: https://github.com/patrickarlt/
demo: 
compatible-v0:
compatible-v1: true
---

A set of tools for using ArcGIS services with Leaflet. Support for map services, feature layers, ArcGIS Online tiles and more.
