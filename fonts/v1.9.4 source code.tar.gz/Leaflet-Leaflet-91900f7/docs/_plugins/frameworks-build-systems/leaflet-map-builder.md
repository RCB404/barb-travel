---
name: Leaflet Map Builder
category: frameworks-build-systems
repo: https://github.com/gherardovarando/leaflet-map-builder
author: Gherardo Varando
author-url: https://github.com/gherardovarando
demo: https://gherardovarando.github.io/leaflet-map-builder/
compatible-v0:
compatible-v1: true
---

It populates a leaflet map from a configuration object, can also creates zoom, layers, attribution draw controls.
