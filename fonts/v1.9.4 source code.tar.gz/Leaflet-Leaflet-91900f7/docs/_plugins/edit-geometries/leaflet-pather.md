---
name: Leaflet.Pather
category: edit-geometries
repo: https://github.com/Wildhoney/L.Pather
author: Wildhoney
author-url: https://github.com/Wildhoney
demo: https://pather.herokuapp.com/
compatible-v0:
compatible-v1: true
---

L.Pather is a freehand polyline creator that simplifies the polyline for mutability. Requires D3 support.
