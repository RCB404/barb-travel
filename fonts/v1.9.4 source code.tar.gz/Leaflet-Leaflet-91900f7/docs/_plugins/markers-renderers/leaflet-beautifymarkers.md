---
name: Leaflet.BeautifyMarkers
category: markers-renderers
repo: https://github.com/masajid390/BeautifyMarker
author: Muhammad Arslan Sajid
author-url: https://github.com/masajid390
demo: https://masajid390.github.io/BeautifyMarker/
compatible-v0:
compatible-v1: true
---

Lightweight plugin that adds colorful iconic markers without image and gives full control of style to end user (i.e. Unlimited colors and CSS styling).
