---
name: Leaflet-IIIF
category: non-map-base-layers
repo: https://github.com/mejackreed/Leaflet-IIIF
author: Jack Reed
author-url: https://github.com/mejackreed
demo: http://mejackreed.github.io/Leaflet-IIIF/examples/example.html
compatible-v0:
compatible-v1: true
---

A <a href="https://iiif.io/">IIIF</a> (International Image Interoperability Framework) viewer for Leaflet.
