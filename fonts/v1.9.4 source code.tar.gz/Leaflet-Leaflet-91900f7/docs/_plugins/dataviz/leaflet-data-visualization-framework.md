---
name: Leaflet Data Visualization Framework
category: dataviz
repo: https://github.com/humangeo/leaflet-dvf
author: Scott Fairgrieve
author-url: https://github.com/sfairgrieve
demo: 
compatible-v0:
compatible-v1: true
---

New markers, layers, and utility classes for easy thematic mapping and data visualization.
